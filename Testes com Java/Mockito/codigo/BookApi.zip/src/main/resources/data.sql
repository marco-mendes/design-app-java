INSERT INTO books (id, title, isbn) VALUES 
(1, 'Coração de Tinta', 978-8535907728),
(2, 'Eu sou o número 4', '978-006-19-6955-3'),
(3, 'Harry Potter e A Pedra Filosofal', '9788551001462'),
(4, 'A Bússola de ouro', '9788573028423'),
(5, 'A Ultima Música', '9788563219077');